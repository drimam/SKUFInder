export interface Product {
  id: string;
  sku: string;
  name: string;
  linkUrl: string;
  costPrice: number;
  remarks: string;
  createdAt: string;
}

export type SortOption = 'latest' | 'serial' | 'oldest';