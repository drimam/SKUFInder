import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { useTheme } from '../context/ThemeContext';

interface AddProductModalProps {
  visible: boolean;
  onClose: () => void;
  onAdd: (product: {
    name: string;
    linkUrl: string;
    costPrice: number;
    remarks: string;
  }) => void;
}

export function AddProductModal({ visible, onClose, onAdd }: AddProductModalProps) {
  const { theme } = useTheme();
  const [name, setName] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [costPrice, setCostPrice] = useState('');
  const [remarks, setRemarks] = useState('');

  const handleSubmit = () => {
    if (!name || !linkUrl || !costPrice) {
      return;
    }

    onAdd({
      name,
      linkUrl,
      costPrice: parseFloat(costPrice),
      remarks,
    });

    setName('');
    setLinkUrl('');
    setCostPrice('');
    setRemarks('');
    onClose();
  };

  const isDark = theme === 'dark';
  const styles = createStyles(isDark);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <ScrollView style={styles.scrollView}>
            <Text style={styles.title}>Add New Product</Text>

            <Text style={styles.label}>Product Name *</Text>
            <TextInput
              style={styles.input}
              value={name}
              onChangeText={setName}
              placeholder="Enter product name"
              placeholderTextColor={isDark ? '#666' : '#999'}
            />

            <Text style={styles.label}>Link URL *</Text>
            <TextInput
              style={styles.input}
              value={linkUrl}
              onChangeText={setLinkUrl}
              placeholder="Enter product URL"
              placeholderTextColor={isDark ? '#666' : '#999'}
              autoCapitalize="none"
            />

            <Text style={styles.label}>Cost Price (INR) *</Text>
            <TextInput
              style={styles.input}
              value={costPrice}
              onChangeText={setCostPrice}
              placeholder="Enter cost price"
              placeholderTextColor={isDark ? '#666' : '#999'}
              keyboardType="numeric"
            />

            <Text style={styles.label}>Remarks</Text>
            <TextInput
              style={[styles.input, styles.remarksInput]}
              value={remarks}
              onChangeText={setRemarks}
              placeholder="Enter remarks"
              placeholderTextColor={isDark ? '#666' : '#999'}
              multiline
            />

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={[styles.button, styles.cancelButton]}
                onPress={onClose}
              >
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, styles.addButton]}
                onPress={handleSubmit}
              >
                <Text style={styles.buttonText}>Add Product</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const createStyles = (isDark: boolean) =>
  StyleSheet.create({
    centeredView: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalView: {
      width: '90%',
      maxHeight: '80%',
      backgroundColor: isDark ? '#1a1a1a' : 'white',
      borderRadius: 20,
      padding: 20,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 5,
    },
    scrollView: {
      width: '100%',
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 20,
      textAlign: 'center',
      color: isDark ? '#fff' : '#000',
    },
    label: {
      fontSize: 16,
      marginBottom: 5,
      color: isDark ? '#fff' : '#000',
    },
    input: {
      borderWidth: 1,
      borderColor: isDark ? '#333' : '#ddd',
      borderRadius: 8,
      padding: 12,
      marginBottom: 15,
      fontSize: 16,
      backgroundColor: isDark ? '#2a2a2a' : '#fff',
      color: isDark ? '#fff' : '#000',
    },
    remarksInput: {
      height: 100,
      textAlignVertical: 'top',
    },
    buttonContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginTop: 20,
    },
    button: {
      flex: 1,
      padding: 15,
      borderRadius: 8,
      marginHorizontal: 5,
    },
    cancelButton: {
      backgroundColor: isDark ? '#444' : '#ddd',
    },
    addButton: {
      backgroundColor: '#007AFF',
    },
    buttonText: {
      color: isDark ? '#fff' : '#000',
      textAlign: 'center',
      fontSize: 16,
      fontWeight: '600',
    },
  });