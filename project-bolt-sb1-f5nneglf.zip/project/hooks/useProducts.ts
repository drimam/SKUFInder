import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { format } from 'date-fns';
import { Product, SortOption } from '../types/Product';

export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const savedProducts = await AsyncStorage.getItem('products');
      if (savedProducts) {
        setProducts(JSON.parse(savedProducts));
      }
      setLoading(false);
    } catch (err) {
      setError('Failed to load products');
      setLoading(false);
    }
  };

  const generateSKU = async () => {
    const date = new Date();
    const prefix = format(date, 'ddMM');
    const existingProducts = await AsyncStorage.getItem('products');
    const products = existingProducts ? JSON.parse(existingProducts) : [];
    const serialNumber = (products.length + 1).toString().padStart(3, '0');
    return `${prefix}${serialNumber}`;
  };

  const addProduct = async (product: Omit<Product, 'id' | 'sku' | 'createdAt'>) => {
    try {
      const sku = await generateSKU();
      const newProduct: Product = {
        id: Date.now().toString(),
        sku,
        ...product,
        createdAt: new Date().toISOString(),
      };

      const updatedProducts = [...products, newProduct];
      await AsyncStorage.setItem('products', JSON.stringify(updatedProducts));
      setProducts(updatedProducts);
      return true;
    } catch (err) {
      setError('Failed to add product');
      return false;
    }
  };

  const deleteProducts = async (productIds: string[]) => {
    try {
      const updatedProducts = products.filter(
        (product) => !productIds.includes(product.id)
      );
      await AsyncStorage.setItem('products', JSON.stringify(updatedProducts));
      setProducts(updatedProducts);
      return true;
    } catch (err) {
      setError('Failed to delete products');
      return false;
    }
  };

  const sortProducts = (sortOption: SortOption) => {
    const sortedProducts = [...products];
    switch (sortOption) {
      case 'latest':
        sortedProducts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'oldest':
        sortedProducts.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        break;
      case 'serial':
        sortedProducts.sort((a, b) => a.sku.localeCompare(b.sku));
        break;
    }
    setProducts(sortedProducts);
  };

  return {
    products,
    loading,
    error,
    addProduct,
    deleteProducts,
    sortProducts,
  };
}