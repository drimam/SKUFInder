import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Linking,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useProducts } from '../hooks/useProducts';
import { AddProductModal } from '../components/AddProductModal';
import { DeleteConfirmationModal } from '../components/DeleteConfirmationModal';
import { useTheme } from '../context/ThemeContext';
import { Product, SortOption } from '../types/Product';
import { format } from 'date-fns';

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  const {
    products,
    loading,
    error,
    addProduct,
    deleteProducts,
    sortProducts,
  } = useProducts();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [sortOption, setSortOption] = useState<SortOption>('latest');

  const isDark = theme === 'dark';
  const styles = createStyles(isDark);

  const handleSort = (option: SortOption) => {
    setSortOption(option);
    sortProducts(option);
  };

  const handleProductSelect = (productId: string) => {
    setSelectedProducts((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const handleDelete = async () => {
    const success = await deleteProducts(selectedProducts);
    if (success) {
      setSelectedProducts([]);
      setShowDeleteModal(false);
    }
  };

  const handleOpenLink = async (url: string) => {
    try {
      await Linking.openURL(url);
    } catch (error) {
      console.error('Error opening URL:', error);
    }
  };

  const filteredProducts = products.filter((product) => {
    const searchLower = searchQuery.toLowerCase();
    return (
      product.sku.toLowerCase().includes(searchLower) ||
      product.name.toLowerCase().includes(searchLower) ||
      product.remarks.toLowerCase().includes(searchLower)
    );
  });

  const renderProduct = useCallback(
    (product: Product) => (
      <View key={product.id} style={styles.productRow}>
        <TouchableOpacity
          style={styles.checkbox}
          onPress={() => handleProductSelect(product.id)}
        >
          <View
            style={[
              styles.checkboxInner,
              selectedProducts.includes(product.id) && styles.checkboxChecked,
            ]}
          />
        </TouchableOpacity>

        <View style={styles.productInfo}>
          <Text style={styles.sku}>{product.sku}</Text>
          <TouchableOpacity onPress={() => handleOpenLink(product.linkUrl)}>
            <Text style={styles.productName}>{product.name}</Text>
          </TouchableOpacity>
          <Text style={styles.price}>₹{product.costPrice.toFixed(2)}</Text>
          <Text style={styles.remarks}>{product.remarks}</Text>
          <Text style={styles.date}>
            {format(new Date(product.createdAt), 'dd/MM/yyyy HH:mm')}
          </Text>
        </View>
      </View>
    ),
    [selectedProducts, isDark]
  );

  if (loading) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>SKU Finder</Text>
        <TouchableOpacity onPress={toggleTheme} style={styles.themeToggle}>
          <Ionicons
            name={isDark ? 'sunny' : 'moon'}
            size={24}
            color={isDark ? '#fff' : '#000'}
          />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <Ionicons
          name="search"
          size={20}
          color={isDark ? '#666' : '#999'}
          style={styles.searchIcon}
        />
        <TextInput
          style={styles.searchInput}
          placeholder="Search by SKU, Product Name, or Remarks"
          placeholderTextColor={isDark ? '#666' : '#999'}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <View style={styles.toolbar}>
        <View style={styles.sortButtons}>
          <TouchableOpacity
            style={[
              styles.sortButton,
              sortOption === 'latest' && styles.sortButtonActive,
            ]}
            onPress={() => handleSort('latest')}
          >
            <Text
              style={[
                styles.sortButtonText,
                sortOption === 'latest' && styles.sortButtonTextActive,
              ]}
            >
              Latest
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.sortButton,
              sortOption === 'serial' && styles.sortButtonActive,
            ]}
            onPress={() => handleSort('serial')}
          >
            <Text
              style={[
                styles.sortButtonText,
                sortOption === 'serial' && styles.sortButtonTextActive,
              ]}
            >
              Serial
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.sortButton,
              sortOption === 'oldest' && styles.sortButtonActive,
            ]}
            onPress={() => handleSort('oldest')}
          >
            <Text
              style={[
                styles.sortButtonText,
                sortOption === 'oldest' && styles.sortButtonTextActive,
              ]}
            >
              Oldest
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.actionButtons}>
          {selectedProducts.length > 0 && (
            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => setShowDeleteModal(true)}
            >
              <Ionicons name="trash" size={20} color="#fff" />
              <Text style={styles.deleteButtonText}>
                Delete ({selectedProducts.length})
              </Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setShowAddModal(true)}
          >
            <Ionicons name="add" size={20} color="#fff" />
            <Text style={styles.addButtonText}>Add Product</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.productList}>
        {filteredProducts.map(renderProduct)}
      </ScrollView>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Developed by: Think Mero Technologies Pvt Ltd
        </Text>
      </View>

      <AddProductModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={addProduct}
      />

      <DeleteConfirmationModal
        visible={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleDelete}
        selectedCount={selectedProducts.length}
      />
    </View>
  );
}

const createStyles = (isDark: boolean) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: isDark ? '#000' : '#f5f5f5',
      paddingTop: Platform.OS === 'ios' ? 60 : 40,
    },
    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingHorizontal: 20,
      marginBottom: 20,
    },
    title: {
      fontSize: 28,
      fontWeight: 'bold',
      color: isDark ? '#fff' : '#000',
    },
    themeToggle: {
      padding: 8,
    },
    searchContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: isDark ? '#1a1a1a' : '#fff',
      marginHorizontal: 20,
      marginBottom: 20,
      borderRadius: 10,
      padding: 10,
    },
    searchIcon: {
      marginRight: 10,
    },
    searchInput: {
      flex: 1,
      fontSize: 16,
      color: isDark ? '#fff' : '#000',
    },
    toolbar: {
      paddingHorizontal: 20,
      marginBottom: 20,
    },
    sortButtons: {
      flexDirection: 'row',
      marginBottom: 10,
    },
    sortButton: {
      paddingVertical: 8,
      paddingHorizontal: 16,
      borderRadius: 20,
      marginRight: 10,
      backgroundColor: isDark ? '#1a1a1a' : '#fff',
    },
    sortButtonActive: {
      backgroundColor: '#007AFF',
    },
    sortButtonText: {
      color: isDark ? '#fff' : '#000',
    },
    sortButtonTextActive: {
      color: '#fff',
    },
    actionButtons: {
      flexDirection: 'row',
      justifyContent: 'flex-end',
    },
    deleteButton: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#ff3b30',
      paddingVertical: 8,
      paddingHorizontal: 16,
      borderRadius: 20,
      marginRight: 10,
    },
    deleteButtonText: {
      color: '#fff',
      marginLeft: 5,
    },
    addButton: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#007AFF',
      paddingVertical: 8,
      paddingHorizontal: 16,
      borderRadius: 20,
    },
    addButtonText: {
      color: '#fff',
      marginLeft: 5,
    },
    productList: {
      flex: 1,
    },
    productRow: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: isDark ? '#1a1a1a' : '#fff',
      marginHorizontal: 20,
      marginBottom: 10,
      borderRadius: 10,
      padding: 15,
    },
    checkbox: {
      width: 24,
      height: 24,
      borderWidth: 2,
      borderColor: isDark ? '#666' : '#ccc',
      borderRadius: 6,
      marginRight: 15,
      justifyContent: 'center',
      alignItems: 'center',
    },
    checkboxInner: {
      width: 14,
      height: 14,
      borderRadius: 3,
    },
    checkboxChecked: {
      backgroundColor: '#007AFF',
    },
    productInfo: {
      flex: 1,
    },
    sku: {
      fontSize: 14,
      color: isDark ? '#666' : '#999',
      marginBottom: 5,
    },
    productName: {
      fontSize: 18,
      fontWeight: '600',
      color: '#007AFF',
      marginBottom: 5,
    },
    price: {
      fontSize: 16,
      color: isDark ? '#fff' : '#000',
      marginBottom: 5,
    },
    remarks: {
      fontSize: 14,
      color: isDark ? '#999' : '#666',
      marginBottom: 5,
    },
    date: {
      fontSize: 12,
      color: isDark ? '#666' : '#999',
    },
    footer: {
      padding: 20,
      alignItems: 'center',
    },
    footerText: {
      fontSize: 12,
      color: isDark ? '#666' : '#999',
    },
    loadingText: {
      fontSize: 18,
      color: isDark ? '#fff' : '#000',
      textAlign: 'center',
      marginTop: 50,
    },
    errorText: {
      fontSize: 18,
      color: '#ff3b30',
      textAlign: 'center',
      marginTop: 50,
    },
  });